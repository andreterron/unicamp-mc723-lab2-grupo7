/**
 * @file      alarm.c
 * @author    The ArchC Team
 *            http://www.archc.org/
 *
 *            Computer Systems Laboratory (LSC)
 *            IC-UNICAMP
 *            http://www.lsc.ic.unicamp.br/
 *
 * @version   1.0
 * @date      Mon, 19 Jun 2006 15:33:20 -0300
 *
 * @brief     
 *
 * @attention Copyright (C) 2002-2006 --- The ArchC Team
 *
 * @note      There is no support for signals yet. We just return 
 *            "no previously scheduled alarm"
 */

int
alarm(unsigned int seconds)
{
  return 0;
}
